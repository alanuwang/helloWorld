from .core import *

__all__ = ['OutlookAccount', 'Message', 'Contact', 'Folder', 'Attachment']
__version__ = '4.2.2'
__release__ = '4.2.2'
